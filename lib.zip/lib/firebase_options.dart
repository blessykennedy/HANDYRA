import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Replace the placeholder values below with your actual Firebase project configuration
/// from the Firebase Console (https://console.firebase.google.com).
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAS2YdR0wh6WCI1TsbSzzDrvvNy2IRPFzA',
    appId: '1:495164181397:web:c43562c23bdec8fc4a049c',
    messagingSenderId: '495164181397',
    projectId: 'handyra-app-5261',
    authDomain: 'handyra-app-5261.firebaseapp.com',
    storageBucket: 'handyra-app-5261.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyB35QhviaT94e9XIYUH-hqTeIFJ8CEIobI',
    appId: '1:495164181397:android:73c5ea22cb3ebd394a049c',
    messagingSenderId: '495164181397',
    projectId: 'handyra-app-5261',
    storageBucket: 'handyra-app-5261.firebasestorage.app',
  );
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyD5mCtw7KcgDPmvFXtwObA516_C-wn5qPs',
    appId: '1:495164181397:ios:d3ec2a60680f46a34a049c',
    messagingSenderId: '495164181397',
    projectId: 'handyra-app-5261',
    storageBucket: 'handyra-app-5261.firebasestorage.app',
    iosBundleId: 'com.example.handyra',
  );
  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyD5mCtw7KcgDPmvFXtwObA516_C-wn5qPs',
    appId: '1:495164181397:ios:d3ec2a60680f46a34a049c',
    messagingSenderId: '495164181397',
    projectId: 'handyra-app-5261',
    storageBucket: 'handyra-app-5261.firebasestorage.app',
    iosBundleId: 'com.example.handyra',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyAS2YdR0wh6WCI1TsbSzzDrvvNy2IRPFzA',
    appId: '1:495164181397:web:54225ac19031f4844a049c',
    messagingSenderId: '495164181397',
    projectId: 'handyra-app-5261',
    authDomain: 'handyra-app-5261.firebaseapp.com',
    storageBucket: 'handyra-app-5261.firebasestorage.app',
  );
}
