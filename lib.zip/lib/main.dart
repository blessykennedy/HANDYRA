import 'dart:ui' show PointerDeviceKind;

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'screens/splash_page.dart';
import 'screens/role_page.dart';
import 'screens/intro_page.dart';
import 'screens/login_page.dart';
import 'screens/signup_page.dart';
import 'screens/main_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint('Firebase initialization note: $e');
  }
  runApp(const MyApp());
}

class AppScrollBehavior extends MaterialScrollBehavior {
  const AppScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => {
    PointerDeviceKind.touch,
    PointerDeviceKind.mouse,
    PointerDeviceKind.trackpad,
    PointerDeviceKind.stylus,
  };
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      scrollBehavior: const AppScrollBehavior(),
      debugShowCheckedModeBanner: false,
      title: 'Handyra',
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        final width = mq.size.width > 430 ? 430.0 : mq.size.width;
        return ColoredBox(
          color: const Color(0xFFE8D2C3),
          child: Center(
            child: SizedBox(
              width: width,
              child: MediaQuery(
                data: mq.copyWith(size: Size(width, mq.size.height)),
                child: child!,
              ),
            ),
          ),
        );
      },
      initialRoute: '/',
      routes: {
        '/': (_) => const SplashPage(),
        '/role': (_) => const RolePage(),
        '/intro': (_) => const IntroPage(),
        '/login': (_) => const LoginPage(),
        '/home': (_) => const MainShell(),
        '/signup': (_) => const SignUpPage(),
        '/provider': (_) =>
        const _Placeholder('Service provider flow coming next'),
      },
    );
  }
}

class _Placeholder extends StatelessWidget {
  const _Placeholder(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(child: Text(text)),
    );
  }
}