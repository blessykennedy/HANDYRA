import 'package:flutter/material.dart';

import 'screens/provider_dashboard.dart';
import 'screens/booking_requests.dart';
import 'screens/my_bookings.dart';
import 'screens/earnings.dart';
import 'screens/profile_screen.dart';
import 'screens/portfolio_screen.dart';

void main() {
runApp(const MyApp());
}

class MyApp extends StatelessWidget {
const MyApp({super.key});

@override
Widget build(BuildContext context) {
return MaterialApp(
debugShowCheckedModeBanner: false,
title: 'Provider App',

theme: ThemeData(
useMaterial3: false,
scaffoldBackgroundColor: Colors.white,
fontFamily: 'Roboto',
),

initialRoute: '/home',

routes: {
'/home': (context) => const ProviderDashboard(),

'/requests': (context) => const BookingRequests(),

'/bookings': (context) => const MyBookings(),

'/earnings': (context) => const Earnings(),

'/profile': (context) => const ProfileScreen(),

'/portfolio': (context) => const PortfolioScreen(),
},
);
}
}

