import 'package:flutter/material.dart';

class RatingCard extends StatelessWidget {
  const RatingCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: InkWell(
        onTap: () {
          showModalBottomSheet(
            context: context,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            builder: (context) => Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Customer Reviews (4.9 ★)",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  const ListTile(
                    leading: CircleAvatar(backgroundImage: NetworkImage("https://i.pravatar.cc/150?img=47")),
                    title: Text("Daffne ⭐⭐⭐⭐⭐"),
                    subtitle: Text("Absolutely amazing work! Priya is incredibly talented and professional."),
                  ),
                  const ListTile(
                    leading: CircleAvatar(backgroundImage: NetworkImage("https://i.pravatar.cc/150?img=32")),
                    title: Text("Roshini ⭐⭐⭐⭐⭐"),
                    subtitle: Text("Loved the party makeup, lasted the whole night!"),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF654B3C),
                      ),
                      child: const Text("Close", style: TextStyle(color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
        borderRadius: BorderRadius.circular(15),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: const Color(0xFFF1E9DF),
            borderRadius: BorderRadius.circular(15),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Row(
                children: const [

                  Icon(
                    Icons.star,
                    color: Colors.amber,
                    size: 30,
                  ),

                  SizedBox(width: 8),

                  Text(
                    "4.9",
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 2),

              const Text(
                "312 Reviews, Top Provider",
                style: TextStyle(
                  fontSize: 9,
                  color: Colors.black54,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                "“Absolutely amazing work! Priya is\n"
                    "incredibly talented...”",
                style: TextStyle(
                  fontSize: 10,
                  height: 1.4,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}