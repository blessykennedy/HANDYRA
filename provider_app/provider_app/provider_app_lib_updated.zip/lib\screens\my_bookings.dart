import 'package:flutter/material.dart';

import '../widgets/bottom_nav.dart';
import '../widgets/my_booking_card.dart';

class MyBookings extends StatefulWidget {
  const MyBookings({super.key});

  @override
  State<MyBookings> createState() => _MyBookingsState();
}

class _MyBookingsState extends State<MyBookings> {
  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: Column(
          children: [

            // ==========================================
            // HEADER
            // ==========================================

            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(
                20,
                25,
                20,
                22,
              ),
              color: const Color(0xFFF4E0D2),

              child: const Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [

                  Text(
                    "My Bookings",
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  SizedBox(height: 3),

                  Text(
                    "Manage your service appointments",
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),

            // ==========================================
            // TABS
            // ==========================================

            Container(
              height: 45,
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(
                  bottom: BorderSide(
                    color: Color(0xFFE0E0E0),
                  ),
                ),
              ),

              child: Row(
                children: [

                  _buildTab(
                    "Upcoming",
                    0,
                  ),

                  _buildTab(
                    "Ongoing",
                    1,
                  ),

                  _buildTab(
                    "Completed",
                    2,
                  ),
                ],
              ),
            ),

            // ==========================================
            // BOOKING LIST
            // ==========================================

            Expanded(
              child: _buildBookings(),
            ),
          ],
        ),
      ),

      // ==========================================
      // BOTTOM NAVIGATION
      // ==========================================

      bottomNavigationBar: const BottomNav(
        selectedIndex: 2,
      ),
    );
  }

  // ==========================================
  // TAB
  // ==========================================

  Widget _buildTab(
      String title,
      int index,
      ) {
    final bool selected = selectedTab == index;

    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedTab = index;
          });
        },

        child: Container(
          alignment: Alignment.center,

          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: selected
                    ? Colors.black
                    : Colors.transparent,
                width: 2,
              ),
            ),
          ),

          child: Text(
            title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: selected
                  ? FontWeight.bold
                  : FontWeight.w500,
              color: selected
                  ? Colors.black
                  : Colors.grey,
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================
  // BOOKINGS
  // ==========================================

  Widget _buildBookings() {

    // UPCOMING
    if (selectedTab == 0) {
      return ListView(
        padding: const EdgeInsets.only(
          top: 20,
          bottom: 20,
        ),

        children: const [

          MyBookingCard(
            name: "Daffne",
            service: "Bridal Makeup",
            price: "₹ 3,500",
            date: "Dec 20, 2024",
            time: "08:30AM",
            location: "Anna nagar, Chennai",
            status: "upcoming",
            image:
            "https://i.pravatar.cc/150?img=47",
          ),

          SizedBox(height: 18),

          MyBookingCard(
            name: "Roshini",
            service: "Party Makeup",
            price: "₹ 1,200",
            date: "Dec 22, 2024",
            time: "05:00PM",
            location: "Guindy, Chennai",
            status: "upcoming",
            image:
            "https://i.pravatar.cc/150?img=32",
          ),
        ],
      );
    }

    // ONGOING
    if (selectedTab == 1) {
      return ListView(
        padding: const EdgeInsets.only(
          top: 20,
          bottom: 20,
        ),

        children: const [

          MyBookingCard(
            name: "No Ongoing Booking",
            service: "Currently no appointment",
            price: "",
            date: "",
            time: "",
            location: "",
            status: "ongoing",
            image:
            "https://i.pravatar.cc/150?img=12",
          ),
        ],
      );
    }

    // COMPLETED
    return ListView(
      padding: const EdgeInsets.only(
        top: 20,
        bottom: 20,
      ),

      children: const [

        MyBookingCard(
          name: "Meena",
          service: "Engagement Makeup",
          price: "₹ 2,500",
          date: "Dec 10, 2024",
          time: "09:00AM",
          location: "Nungambakkam, Chennai",
          status: "completed",
          image:
          "https://i.pravatar.cc/150?img=45",
        ),
      ],
    );
  }
}