import 'package:flutter/material.dart';

import '../widgets/bottom_nav.dart';
import '../widgets/booking_request_card.dart';

class BookingRequests extends StatefulWidget {
  const BookingRequests({super.key});

  @override
  State<BookingRequests> createState() => _BookingRequestsState();
}

class _BookingRequestsState extends State<BookingRequests> {

  int selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: Column(
          children: [

            // --------------------------------
            // HEADER
            // --------------------------------

            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(
                20,
                25,
                20,
                22,
              ),
              color: const Color(0xFFF4E0D2),

              child: const Column(
                crossAxisAlignment:
                CrossAxisAlignment.start,
                children: [

                  Text(
                    "Booking Requests",
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  SizedBox(height: 5),

                  Text(
                    "2 new requests pending",
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),

            // --------------------------------
            // TABS
            // --------------------------------

            Container(
              height: 45,
              decoration: const BoxDecoration(
                color: Colors.white,

                border: Border(
                  bottom: BorderSide(
                    color: Color(0xFFE0E0E0),
                  ),
                ),
              ),

              child: Row(
                children: [

                  _tab(
                    title: "New",
                    count: "2",
                    index: 0,
                  ),

                  _tab(
                    title: "Accepted",
                    index: 1,
                  ),

                  _tab(
                    title: "Rejected",
                    index: 2,
                  ),
                ],
              ),
            ),

            // --------------------------------
            // REQUEST LIST
            // --------------------------------

            Expanded(
              child: _buildContent(),
            ),
          ],
        ),
      ),

      // --------------------------------
      // BOTTOM NAVIGATION
      // --------------------------------

      bottomNavigationBar: const BottomNav(
        selectedIndex: 1,
      ),
    );
  }


  // --------------------------------
  // TAB
  // --------------------------------

  Widget _tab({
    required String title,
    required int index,
    String? count,
  }) {

    final bool selected =
        selectedTab == index;

    return Expanded(
      child: GestureDetector(

        onTap: () {
          setState(() {
            selectedTab = index;
          });
        },

        child: Container(
          alignment: Alignment.center,

          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: selected
                    ? Colors.black
                    : Colors.transparent,
                width: 2,
              ),
            ),
          ),

          child: Row(
            mainAxisAlignment:
            MainAxisAlignment.center,

            children: [

              Text(
                title,
                style: TextStyle(
                  fontSize: 13,

                  fontWeight: selected
                      ? FontWeight.bold
                      : FontWeight.w500,

                  color: selected
                      ? Colors.black
                      : Colors.grey,
                ),
              ),

              if (count != null) ...[

                const SizedBox(width: 5),

                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 2,
                  ),

                  decoration: BoxDecoration(
                    color: const Color(0xFFE7D6C8),
                    borderRadius:
                    BorderRadius.circular(10),
                  ),

                  child: Text(
                    count,
                    style: const TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }


  // --------------------------------
  // CONTENT
  // --------------------------------

  Widget _buildContent() {

    if (selectedTab == 0) {
      return ListView(
        padding: const EdgeInsets.only(
          top: 18,
          bottom: 20,
        ),
        children: [

          BookingRequestCard(
            name: "Daffne",
            service: "Bridal Makeup",
            price: "₹3,500",
            date: "Dec 20, 2024",
            time: "08:30AM",
            location: "Anna nagar, Chennai",
            distance: "3.2Km",
            description:
            "Soft bridal look, prefer natural tones. Have skin sensitivity, please use hypoallergenic products.",
            image:
            "https://i.pravatar.cc/150?img=47",
          ),

          const SizedBox(height: 18),

          BookingRequestCard(
            name: "Roshini",
            service: "Party Makeup",
            price: "₹1,200",
            date: "Dec 22, 2024",
            time: "05:00PM",
            location: "Guindy, Chennai",
            distance: "3.2Km",
            description:
            "Bold party look for New Year event.",
            image:
            "https://i.pravatar.cc/150?img=32",
          ),
        ],
      );
    }


    if (selectedTab == 1) {
      return const Center(
        child: Text(
          "No accepted bookings yet",
          style: TextStyle(
            color: Colors.grey,
            fontSize: 14,
          ),
        ),
      );
    }


    return const Center(
      child: Text(
        "No rejected requests",
        style: TextStyle(
          color: Colors.grey,
          fontSize: 14,
        ),
      ),
    );
  }
}